package com.example.mvc.controller;

import com.example.mvc.model.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class TestController {
    @GetMapping("/test")
    public String testView(Model model){
        User user = new User();
        user.setName("abcd");
        model.addAttribute("user", user);
        return "test";
    }
}