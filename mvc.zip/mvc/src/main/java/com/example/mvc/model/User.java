package com.example.mvc.model;

import lombok.Data;

@Data
public class User {
    private String name;
}